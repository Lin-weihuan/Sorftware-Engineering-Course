package com.project.demo.controller;

import com.project.demo.entity.PatientEvaluation;
import com.project.demo.service.PatientEvaluationService;
import com.project.demo.controller.base.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import jakarta.persistence.Query;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.*;


/**
 * 患者评价：(PatientEvaluation)表控制层
 *
 */
@RestController
@RequestMapping("/patient_evaluation")
public class PatientEvaluationController extends BaseController<PatientEvaluation, PatientEvaluationService> {

    /**
     * 患者评价对象
     */
    @Autowired
    public PatientEvaluationController(PatientEvaluationService service) {
        setService(service);
    }



    @PostMapping("/add")
    @Transactional
    public Map<String, Object> add(HttpServletRequest request) throws IOException {
        Map<String,Object> paramMap = service.readBody(request.getReader());
        this.addMap(paramMap);
        return success(1);
    }


}
