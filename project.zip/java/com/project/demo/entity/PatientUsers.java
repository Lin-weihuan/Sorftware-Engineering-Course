package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 患者用户：(PatientUsers)表实体类
 *
 */
@TableName("`patient_users`")
@Data
@EqualsAndHashCode(callSuper = false)
public class PatientUsers implements Serializable {

    // PatientUsers编号
    @TableId(value = "patient_users_id", type = IdType.AUTO)
    private Integer patient_users_id;

    // 患者姓名
    @TableField(value = "`patient_name`")
    private String patient_name;
    // 患者性别
    @TableField(value = "`patient_gender`")
    private String patient_gender;
    // 患者电话
    @TableField(value = "`patients_phone_number`")
    private String patients_phone_number;









    // 用户编号
    @TableField(value = "user_id")
    private Integer userId;











			


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
