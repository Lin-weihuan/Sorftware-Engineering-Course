package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 患者评价：(PatientEvaluation)表实体类
 *
 */
@TableName("`patient_evaluation`")
@Data
@EqualsAndHashCode(callSuper = false)
public class PatientEvaluation implements Serializable {

    // PatientEvaluation编号
    @TableId(value = "patient_evaluation_id", type = IdType.AUTO)
    private Integer patient_evaluation_id;

    // 医生用户
    @TableField(value = "`doctor_users`")
    private Integer doctor_users;
    // 医生姓名
    @TableField(value = "`doctors_name`")
    private String doctors_name;
    // 患者用户
    @TableField(value = "`patient_users`")
    private Integer patient_users;
    // 患者姓名
    @TableField(value = "`patient_name`")
    private String patient_name;
    // 患者评价
    @TableField(value = "`patient_evaluation`")
    private String patient_evaluation;




















				// 来源表
	@TableField(value = "source_table")
	private String source_table;
	
	// 来源ID
	@TableField(value = "source_id")
	private Integer source_id;
	
	// 来源用户ID
	@TableField(value = "source_user_id")
	private Integer source_user_id;
	


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
