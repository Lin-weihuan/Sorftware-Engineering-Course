package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 科室名称：(DepartmentName)表实体类
 *
 */
@TableName("`department_name`")
@Data
@EqualsAndHashCode(callSuper = false)
public class DepartmentName implements Serializable {

    // DepartmentName编号
    @TableId(value = "department_name_id", type = IdType.AUTO)
    private Integer department_name_id;

    // 科室名称
    @TableField(value = "`department_name`")
    private String department_name;




















			


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
