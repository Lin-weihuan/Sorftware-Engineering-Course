package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 医生排班：(DoctorScheduling)表实体类
 *
 */
@TableName("`doctor_scheduling`")
@Data
@EqualsAndHashCode(callSuper = false)
public class DoctorScheduling implements Serializable {

    // DoctorScheduling编号
    @TableId(value = "doctor_scheduling_id", type = IdType.AUTO)
    private Integer doctor_scheduling_id;

    // 排班名称
    @TableField(value = "`schedule_name`")
    private String schedule_name;
    // 排班科室
    @TableField(value = "`scheduling_department`")
    private String scheduling_department;
    // 排班医生
    @TableField(value = "`scheduling_doctors`")
    private String scheduling_doctors;




















			
	// 单人单日最多排次数
	@TableField(value = "scheduling_number")
	private Integer scheduling_number;
	
	// 周期
	@TableField(value = "scheduling_period")
	private String scheduling_period;
	
	// 时间设置
	@TableField(value = "scheduling_date_options")
	private String scheduling_date_options;
	
	// 排期表
	@TableField(value = "timetable")
	private String timetable;


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
