package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 医生信息：(DoctorInformation)表实体类
 *
 */
@TableName("`doctor_information`")
@Data
@EqualsAndHashCode(callSuper = false)
public class DoctorInformation implements Serializable {

    // DoctorInformation编号
    @TableId(value = "doctor_information_id", type = IdType.AUTO)
    private Integer doctor_information_id;

    // 医生用户
    @TableField(value = "`doctor_users`")
    private Integer doctor_users;
    // 医生姓名
    @TableField(value = "`doctors_name`")
    private String doctors_name;
    // 科室名称
    @TableField(value = "`department_name`")
    private String department_name;
    // 医生电话
    @TableField(value = "`doctors_phone_number`")
    private String doctors_phone_number;
    // 预约费用
    @TableField(value = "`appointment_fee`")
    private Double appointment_fee;
    // 擅长领域
    @TableField(value = "`specializes_in_specific_fields`")
    private String specializes_in_specific_fields;
    // 医生相片
    @TableField(value = "`doctors_photo`")
    private String doctors_photo;
    // 医生简介
    @TableField(value = "`doctor_introduction`")
    private String doctor_introduction;


    // 点赞数
    @TableField(value = "praise_len")
    private Integer praise_len;

    // 收藏数
    @TableField(value = "collect_len")
    private Integer collect_len;

    // 评论数
    @TableField(value = "comment_len")
    private Integer comment_len;















		// 挂号限制次数
	@TableField(value = "registration_and_appointment_limit_times")
	private String registration_and_appointment_limit_times;
	
			


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
