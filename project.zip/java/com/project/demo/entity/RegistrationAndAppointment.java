package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 挂号预约：(RegistrationAndAppointment)表实体类
 *
 */
@TableName("`registration_and_appointment`")
@Data
@EqualsAndHashCode(callSuper = false)
public class RegistrationAndAppointment implements Serializable {

    // RegistrationAndAppointment编号
    @TableId(value = "registration_and_appointment_id", type = IdType.AUTO)
    private Integer registration_and_appointment_id;

    // 医生用户
    @TableField(value = "`doctor_users`")
    private Integer doctor_users;
    // 医生姓名
    @TableField(value = "`doctors_name`")
    private String doctors_name;
    // 科室名称
    @TableField(value = "`department_name`")
    private String department_name;
    // 预约费用
    @TableField(value = "`appointment_fee`")
    private Double appointment_fee;
    // 患者用户
    @TableField(value = "`patient_users`")
    private Integer patient_users;
    // 患者姓名
    @TableField(value = "`patient_name`")
    private String patient_name;
    // 患者性别
    @TableField(value = "`patient_gender`")
    private String patient_gender;
    // 患者电话
    @TableField(value = "`patients_phone_number`")
    private String patients_phone_number;
    // 预约时间
    @TableField(value = "`time_of_appointment`")
    private Timestamp time_of_appointment;
    // 预约时段
    @TableField(value = "`appointment_period`")
    private String appointment_period;
    // 病情描述
    @TableField(value = "`disease_description`")
    private String disease_description;






    // 支付状态
    @TableField(value = "pay_state")
    private String pay_state;

    // 支付类型: 微信、支付宝、网银
    @TableField(value = "pay_type")
    private String pay_type;













		// 就诊限制次数
	@TableField(value = "doctors_visit_limit_times")
	private String doctors_visit_limit_times;
	
		// 来源表
	@TableField(value = "source_table")
	private String source_table;
	
	// 来源ID
	@TableField(value = "source_id")
	private Integer source_id;
	
	// 来源用户ID
	@TableField(value = "source_user_id")
	private Integer source_user_id;
			


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
