package com.project.demo.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 医生就诊：(DoctorsVisit)表实体类
 *
 */
@TableName("`doctors_visit`")
@Data
@EqualsAndHashCode(callSuper = false)
public class DoctorsVisit implements Serializable {

    // DoctorsVisit编号
    @TableId(value = "doctors_visit_id", type = IdType.AUTO)
    private Integer doctors_visit_id;

    // 医生用户
    @TableField(value = "`doctor_users`")
    private Integer doctor_users;
    // 医生姓名
    @TableField(value = "`doctors_name`")
    private String doctors_name;
    // 患者用户
    @TableField(value = "`patient_users`")
    private Integer patient_users;
    // 患者姓名
    @TableField(value = "`patient_name`")
    private String patient_name;
    // 患者性别
    @TableField(value = "`patient_gender`")
    private String patient_gender;
    // 病情描述
    @TableField(value = "`disease_description`")
    private String disease_description;
    // 建档时间
    @TableField(value = "`filing_time`")
    private Timestamp filing_time;
    // 诊断结果
    @TableField(value = "`diagnostic_results`")
    private String diagnostic_results;
    // 治疗方案
    @TableField(value = "`treatment_plan`")
    private String treatment_plan;
    // 开处方药
    @TableField(value = "`prescribing_medication`")
    private String prescribing_medication;
    // 药品费用
    @TableField(value = "`drug_expenses`")
    private Double drug_expenses;
    // 检查费用
    @TableField(value = "`inspection_fee`")
    private Double inspection_fee;
    // 费用总计
    @TableField(value = "`total_cost`")
    private String total_cost;






    // 支付状态
    @TableField(value = "pay_state")
    private String pay_state;

    // 支付类型: 微信、支付宝、网银
    @TableField(value = "pay_type")
    private String pay_type;













		// 评价限制次数
	@TableField(value = "patient_evaluation_limit_times")
	private String patient_evaluation_limit_times;
	
			// 来源表
	@TableField(value = "source_table")
	private String source_table;
	
	// 来源ID
	@TableField(value = "source_id")
	private Integer source_id;
	
	// 来源用户ID
	@TableField(value = "source_user_id")
	private Integer source_user_id;
		


	// 更新时间
    @TableField(value = "update_time")
    private Timestamp update_time;

    // 创建时间
    @TableField(value = "create_time")
    private Timestamp create_time;

}
