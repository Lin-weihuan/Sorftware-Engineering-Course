package com.project.demo.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 评论：(Comment)表实体类
 *
 * @author xxx
 *@since 202X-XX-XX
 */
@TableName("comment")
@Data
@EqualsAndHashCode(callSuper = false)
public class Comment implements Serializable {

    private static final long serialVersionUID = 897384967462600611L;

    /**
     * 评论ID：
     */
    @TableId(value = "comment_id", type = IdType.AUTO)
    private Integer comment_id;

    /**
     * 评论人ID：
     */
    @TableField(value = "user_id")
    private Integer user_id;

    /**
     * 回复评论ID：空为0
     */
    @TableField(value = "reply_to_id")
    private Integer reply_to_id;

    /**
     * 内容：
     */
    @TableField(value = "content")
    private String content;

    /**
     * 昵称：
     */
    @TableField(value = "nickname")
    private String nickname;

    /**
     * 头像地址：[0,255]
     */
    @TableField(value = "avatar")
    private String avatar;

    /**
     * 创建时间：
     */
    @TableField(value = "create_time")
    private Timestamp create_time;

    /**
     * 更新时间：
     */
    @TableField(value = "update_time")
    private Timestamp update_time;

    /**
     * 来源表：
     */
    @TableField(value = "source_table")
    private String source_table;

    /**
     * 来源字段：
     */
    @TableField(value = "source_field")
    private String source_field;

    /**
     * 来源ID：
     */
    @TableField(value = "source_id")
    private Integer source_id;

}

