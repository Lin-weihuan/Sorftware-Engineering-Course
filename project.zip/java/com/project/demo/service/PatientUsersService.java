package com.project.demo.service;

import com.project.demo.entity.PatientUsers;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 患者用户：(PatientUsers)表服务接口
 *
 */
@Service
public class PatientUsersService extends BaseService<PatientUsers> {

}
