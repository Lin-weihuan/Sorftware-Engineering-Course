package com.project.demo.service;

import com.project.demo.entity.Notice;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 公告：(Notice)表服务接口
 *
 */
@Service
public class NoticeService extends BaseService<Notice> {

}


