package com.project.demo.service;

import com.project.demo.entity.RegistrationAndAppointment;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 挂号预约：(RegistrationAndAppointment)表服务接口
 *
 */
@Service
public class RegistrationAndAppointmentService extends BaseService<RegistrationAndAppointment> {

}
