package com.project.demo.service;

import com.project.demo.entity.DoctorUsers;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 医生用户：(DoctorUsers)表服务接口
 *
 */
@Service
public class DoctorUsersService extends BaseService<DoctorUsers> {

}
