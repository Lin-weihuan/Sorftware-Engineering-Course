package com.project.demo.service;

import com.project.demo.entity.DoctorsVisit;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 医生就诊：(DoctorsVisit)表服务接口
 *
 */
@Service
public class DoctorsVisitService extends BaseService<DoctorsVisit> {

}
