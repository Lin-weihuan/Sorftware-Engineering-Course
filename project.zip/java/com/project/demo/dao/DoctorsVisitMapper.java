package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.DoctorsVisit;
import org.apache.ibatis.annotations.Mapper;

/**
 * 医生就诊：(DoctorsVisit)Mapper接口
 *
 */
@Mapper
public interface DoctorsVisitMapper extends BaseMapper<DoctorsVisit>{

}
