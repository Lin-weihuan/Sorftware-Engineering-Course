package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.PatientEvaluation;
import org.apache.ibatis.annotations.Mapper;

/**
 * 患者评价：(PatientEvaluation)Mapper接口
 *
 */
@Mapper
public interface PatientEvaluationMapper extends BaseMapper<PatientEvaluation>{

}
