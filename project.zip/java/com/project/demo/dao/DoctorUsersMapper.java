package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.DoctorUsers;
import org.apache.ibatis.annotations.Mapper;

/**
 * 医生用户：(DoctorUsers)Mapper接口
 *
 */
@Mapper
public interface DoctorUsersMapper extends BaseMapper<DoctorUsers>{

}
