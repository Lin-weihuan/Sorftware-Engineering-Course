package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.PatientUsers;
import org.apache.ibatis.annotations.Mapper;

/**
 * 患者用户：(PatientUsers)Mapper接口
 *
 */
@Mapper
public interface PatientUsersMapper extends BaseMapper<PatientUsers>{

}
