package com.project.demo.dao;

import com.project.demo.dao.base.BaseMapper;
import com.project.demo.entity.RegistrationAndAppointment;
import org.apache.ibatis.annotations.Mapper;

/**
 * 挂号预约：(RegistrationAndAppointment)Mapper接口
 *
 */
@Mapper
public interface RegistrationAndAppointmentMapper extends BaseMapper<RegistrationAndAppointment>{

}
